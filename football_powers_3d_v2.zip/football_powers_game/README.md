# Football Powers 3D — versión ampliada

Prototipo web 3D de fútbol con poderes, creado para probar en PC y móvil.

## Incluye en esta versión
- Lobby de práctica y estadio de partido.
- Salas multijugador privadas por código mediante Socket.IO.
- Selección de país, rol y personalización visual básica (color de camiseta, número, pelo y tono de piel).
- Modelos humanoides 3D de geometría con animación procedural sencilla de brazos y piernas.
- Controles para pase, tiro, regate, robo normal y barrida deslizante.
- Poderes por posición, efectos de balón y enfriamientos.
- Árbitro central y dos asistentes 3D decorativos; panel para probar tarjetas amarillas y rojas.
- Menú visual de servidores y rangos: Casual, Bronce, Plata, Oro y Diamante.
- Clima soleado, lluvia y nieve; opciones de rendimiento.

## Ejecutar
Requiere Node.js 18 o superior.

```bash
npm install
npm start
```

Abre `http://localhost:3000`.

## Multijugador por internet
Publica el proyecto en un hosting que soporte Node.js y WebSockets (por ejemplo, Render, Railway o un VPS). Configura:
- Build: `npm install`
- Start: `npm start`
- Puerto: variable `PORT` del hosting.

Comparte la URL pública y el código de sala con tus amigos por WhatsApp o Discord.

## Límites importantes del prototipo
- Los servidores/rangos son una pantalla de selección demostrativa; no hay todavía matchmaking público, temporadas, MMR ni guardado de rangos.
- Los árbitros y asistentes son modelos 3D decorativos. Las tarjetas se pueden probar desde el panel, pero no hay detección automática de faltas ni reglas arbitrales completas.
- La personalización actual es visual básica; no incluye tienda de ropa, editor avanzado ni guardar atuendos en cuenta.
- Las animaciones son procedurales y las físicas del balón son una simulación sencilla; no son captura de movimiento ni física profesional.
- Para una experiencia pública segura faltan cuentas, persistencia, moderación, anti-trampas y validación completa del servidor.

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(express.static(__dirname));
app.get('/health', (_req, res) => res.json({ ok: true, game: 'Football Powers 3D' }));

const rooms = new Map();
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const makeCode = () => crypto.randomBytes(3).toString('hex').toUpperCase();

function createRoom() {
  let code = makeCode();
  while (rooms.has(code)) code = makeCode();
  const room = {
    code, stage: 'practice', weather: 'sun', votes: { sun: 0, rain: 0, snow: 0 },
    players: {}, ball: { x: 0, y: 0.55, z: 0, vx: 0, vy: 0, vz: 0, fire: 0 },
    score: [0, 0], lastTouch: null, lastGoalAt: 0
  };
  rooms.set(code, room);
  return room;
}
function publicState(room) {
  return {
    code: room.code, stage: room.stage, weather: room.weather,
    votes: room.votes, score: room.score,
    players: Object.values(room.players).map(p => ({
      id: p.id, name: p.name, country: p.country, role: p.role, team: p.team,
      x: p.x, z: p.z, dirX: p.dirX, dirZ: p.dirZ, sprintUntil: p.sprintUntil
    })),
    ball: room.ball
  };
}
function emitState(room) { io.to(room.code).emit('state', publicState(room)); }
function resetBall(room) {
  room.ball = { x: 0, y: 0.55, z: 0, vx: 0, vy: 0, vz: 0, fire: 0 };
}
function leaveCurrent(socket) {
  const code = socket.data.room;
  if (!code) return;
  const room = rooms.get(code);
  socket.leave(code);
  if (room) {
    delete room.players[socket.id];
    if (!Object.keys(room.players).length) rooms.delete(code);
    else emitState(room);
  }
  socket.data.room = null;
}

io.on('connection', socket => {
  socket.on('createRoom', ({ name, country, role } = {}, cb) => {
    leaveCurrent(socket);
    const room = createRoom();
    const player = makePlayer(socket.id, name, country, role, room);
    room.players[socket.id] = player;
    socket.join(room.code); socket.data.room = room.code;
    cb && cb({ ok: true, code: room.code, id: socket.id, state: publicState(room) });
    emitState(room);
  });
  socket.on('joinRoom', ({ code, name, country, role } = {}, cb) => {
    leaveCurrent(socket);
    code = String(code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return cb && cb({ ok: false, error: 'No existe esa sala. Revisa el código.' });
    if (Object.keys(room.players).length >= 22) return cb && cb({ ok: false, error: 'La sala está llena (máximo 22 jugadores, 11 por equipo).' });
    const player = makePlayer(socket.id, name, country, role, room);
    room.players[socket.id] = player;
    socket.join(code); socket.data.room = code;
    cb && cb({ ok: true, code, id: socket.id, state: publicState(room) });
    emitState(room);
  });
  socket.on('startMatch', () => {
    const room = rooms.get(socket.data.room); if (!room) return;
    room.stage = 'match'; room.votes = { sun: 0, rain: 0, snow: 0 };
    // Put both teams on their own half for kickoff.
    for (const p of Object.values(room.players)) {
      p.x = p.team === 0 ? -12 : 12;
      p.z = (Math.random() - 0.5) * 24;
    }
    resetBall(room); emitState(room);
  });
  socket.on('voteWeather', weather => {
    const room = rooms.get(socket.data.room); if (!room || !['sun', 'rain', 'snow'].includes(weather)) return;
    for (const k of Object.keys(room.votes)) room.votes[k] = 0;
    room.votes[weather] = 1;
    // Majority is evaluated from the latest vote stored per player.
    room.weatherVotes = room.weatherVotes || {};
    room.weatherVotes[socket.id] = weather;
    const tally = { sun: 0, rain: 0, snow: 0 };
    for (const v of Object.values(room.weatherVotes)) tally[v]++;
    room.votes = tally;
    const max = Math.max(...Object.values(tally));
    const winners = Object.keys(tally).filter(k => tally[k] === max);
    room.weather = winners.includes('sun') ? 'sun' : winners[0];
    emitState(room);
  });
  socket.on('input', data => {
    const room = rooms.get(socket.data.room); const p = room && room.players[socket.id]; if (!p) return;
    p.inputX = clamp(Number(data.x) || 0, -1, 1);
    p.inputZ = clamp(Number(data.z) || 0, -1, 1);
    if (Math.abs(p.inputX) + Math.abs(p.inputZ) > 0.08) {
      const len = Math.hypot(p.inputX, p.inputZ) || 1;
      p.dirX = p.inputX / len; p.dirZ = p.inputZ / len;
    }
  });
  socket.on('action', type => {
    const room = rooms.get(socket.data.room); const p = room && room.players[socket.id]; if (!p) return;
    performAction(room, p, String(type || ''));
  });
  socket.on('resetToPractice', () => {
    const room = rooms.get(socket.data.room); if (!room) return;
    room.stage = 'practice'; room.score = [0, 0]; resetBall(room); emitState(room);
  });
  socket.on('disconnect', () => leaveCurrent(socket));
});

function makePlayer(id, name, country, role, room) {
  const teams = Object.values(room.players).reduce((a, p) => (a[p.team]++, a), [0, 0]);
  const team = teams[0] <= teams[1] ? 0 : 1;
  return {
    id, name: String(name || 'Jugador').slice(0, 16), country: String(country || 'Chile').slice(0, 24),
    role: ['keeper', 'defender', 'midfielder', 'attacker'].includes(role) ? role : 'attacker',
    team, x: team === 0 ? -8 : 8, z: (Math.random() - 0.5) * 18,
    dirX: team === 0 ? 1 : -1, dirZ: 0, inputX: 0, inputZ: 0, sprintUntil: 0,
    cooldowns: {}, lastAction: 0
  };
}
function canUse(p, key, cooldown) {
  const now = Date.now(); if ((p.cooldowns[key] || 0) > now) return false;
  p.cooldowns[key] = now + cooldown; return true;
}
function distance2(a, b) { return Math.hypot(a.x - b.x, a.z - b.z); }
function performAction(room, p, type) {
  const now = Date.now(); if (now - p.lastAction < 220) return;
  p.lastAction = now;
  const b = room.ball;
  const near = distance2(p, b) < 3.2;
  const wet = room.weather === 'rain' ? 0.78 : 1;
  const forward = p.team === 0 ? 1 : -1;
  const dx = Math.abs(p.dirX) + Math.abs(p.dirZ) > 0.1 ? p.dirX : forward;
  const dz = Math.abs(p.dirX) + Math.abs(p.dirZ) > 0.1 ? p.dirZ : 0;
  if (type === 'sprint') { if (canUse(p, 'sprint', 12000)) p.sprintUntil = now + 2800; return; }
  if (type === 'dribble') { if (canUse(p, 'dribble', 1800) && near) { b.vx += dx * 5; b.vz += dz * 5; room.lastTouch = p.id; } return; }
  if (type === 'steal' || type === 'slide') { const cd = type === 'slide' ? 6500 : 1800; if (!canUse(p, type, cd)) return; if (near) { b.vx = dx * (type === 'slide' ? 17 : 10); b.vz = dz * (type === 'slide' ? 17 : 10); b.vy = type === 'slide' ? 2.5 : 1; room.lastTouch = p.id; } return; }
  if (type === 'yellowCard' || type === 'redCard') { room.io.to(room.code).emit('discipline', {kind:type === 'yellowCard' ? 'yellow' : 'red', player:p.name}); return; }
  if (type === 'shot' || type === 'pass' || type === 'keeperPass' || type === 'curvePass' || type === 'effectShot' || type === 'chilena' || type === 'defendDive' || type === 'defendHeader' || type === 'keeperClear' || type === 'attackerUltimate') {
    const isKeeper = p.role === 'keeper';
    const isDefender = p.role === 'defender';
    let cd = 1800;
    if (type === 'keeperPass') cd = 9000;
    if (type === 'curvePass') cd = 8500;
    if (type === 'effectShot') cd = 7000;
    if (type === 'chilena') cd = 8500;
    if (type === 'defendDive') cd = 6500;
    if (type === 'defendHeader') cd = 18000;
    if (type === 'keeperClear') cd = 26000;
    if (type === 'attackerUltimate') cd = 28000;
    if (!canUse(p, type, cd)) return;
    if (type === 'defendDive') {
      p.x = clamp(p.x + dx * 6, -48, 48); p.z = clamp(p.z + dz * 6, -28, 28);
      if (near) { b.vx = -forward * 13; b.vy = 4; b.vz = (Math.random() - .5) * 10; room.lastTouch = p.id; }
      return;
    }
    if (type === 'defendHeader') {
      p.x = clamp(p.x + dx * 4, -48, 48);
      if (distance2(p, b) < 8) { b.vx = -forward * 28; b.vy = 11; b.vz = (Math.random() - .5) * 8; b.fire = now + 1700; room.lastTouch = p.id; }
      return;
    }
    if (!near) return;
    let power = 0, lift = 0, curve = 0;
    if (type === 'pass' || type === 'keeperPass' || type === 'curvePass') { power = type === 'curvePass' ? 19 : 15; lift = type === 'curvePass' ? 3.8 : 2.4; curve = type === 'curvePass' ? 7 : 0; }
    if (type === 'shot') { power = 24; lift = 6; }
    if (type === 'effectShot') { power = 27; lift = 7; curve = 10; }
    if (type === 'chilena') { power = 30; lift = 12; curve = 8; }
    if (type === 'keeperClear') { power = 38; lift = 10; curve = 2; b.fire = now + 3000; }
    if (type === 'attackerUltimate') { power = 52; lift = 9; curve = 1; b.fire = now + 3500; }
    if (isKeeper && type === 'keeperClear') { /* keeper ultimate */ }
    b.vx = dx * power * wet; b.vz = dz * power * wet + curve * (p.team === 0 ? 1 : -1);
    b.vy = lift * wet; room.lastTouch = p.id;
  }
}

setInterval(() => {
  const dt = 0.05, now = Date.now();
  for (const room of rooms.values()) {
    for (const p of Object.values(room.players)) {
      let speed = now < p.sprintUntil ? 12.5 : 7.5;
      if (room.weather === 'rain') speed *= 0.86;
      if (room.stage === 'practice') speed *= 1.12;
      const x = p.inputX || 0, z = p.inputZ || 0, len = Math.hypot(x, z) || 1;
      p.x = clamp(p.x + (x / len) * speed * dt, -48, 48);
      p.z = clamp(p.z + (z / len) * speed * dt, -28, 28);
    }
    const b = room.ball;
    b.x += b.vx * dt; b.y += b.vy * dt; b.z += b.vz * dt;
    b.vy -= 19.5 * dt;
    if (b.y < 0.55) { b.y = 0.55; b.vy = Math.abs(b.vy) > 1.1 ? -b.vy * 0.34 : 0; b.vx *= 0.91; b.vz *= 0.91; }
    b.vx *= 0.992; b.vz *= 0.992;
    if (Math.abs(b.z) > 29) { b.z = clamp(b.z, -29, 29); b.vz *= -0.5; }
    if (Math.abs(b.x) > 50) {
      if (room.stage === 'match' && Math.abs(b.z) < 4.2) {
        const scoringTeam = b.x > 0 ? 0 : 1;
        room.score[scoringTeam]++;
        io.to(room.code).emit('goal', { team: scoringTeam, score: room.score });
        room.lastGoalAt = now; resetBall(room);
      } else { b.x = clamp(b.x, -50, 50); b.vx *= -0.55; }
    }
    if (Math.abs(b.x) < 1.7 && Math.abs(b.z) < 1.7 && b.y < 1.7) {
      for (const p of Object.values(room.players)) if (distance2(p, b) < 1.35) {
        b.vx *= 0.92; b.vz *= 0.92; break;
      }
    }
    emitState(room);
  }
}, 50);

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => console.log(`Football Powers 3D en http://localhost:${PORT}`));
